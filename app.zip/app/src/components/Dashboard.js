import React from "react";
import { Box } from "@mui/material";

function Dashboard() {
  console.log("here");
  return (
    <div style={{ marginTop: "50px" }}>
      <Box height={100}>
        <div>Dashboard</div>
        <div></div>
      </Box>
    </div>
  );
}

export default Dashboard;
